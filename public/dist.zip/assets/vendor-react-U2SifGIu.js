import"./vendor-icons-BSe0nMye.js";
