/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "yandex_9a3402ab46b0793b.html",
    "revision": "534f351672abd074c4aabf632953a1fb"
  }, {
    "url": "santehpro-exchange-banner.svg",
    "revision": "e687f0dd24d24e104731926bacbce70c"
  }, {
    "url": "santehpro-exchange-banner.png",
    "revision": "8a5b3b89f5dac2907b2a40424df37156"
  }, {
    "url": "rustore.html",
    "revision": "5e6e762eb25bd9d1426c26b8970e0576"
  }, {
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable.svg",
    "revision": "10e6ea8bb83da1be3cd199bf22aad581"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "6b5be6019b59864f6da13f1ea548d515"
  }, {
    "url": "pwa-512x512.png",
    "revision": "b7fecc08132c7065421ffc992fa19205"
  }, {
    "url": "pwa-192x192.png",
    "revision": "f52061cbd041a7cddbb0e6bdbffeecf0"
  }, {
    "url": "og-image.svg",
    "revision": "50b793c6f4f7293205d029a317901b13"
  }, {
    "url": "og-image.png",
    "revision": "189b0bf1d65b666773c0afacf6ac4290"
  }, {
    "url": "og-image-square.png",
    "revision": "e706d23984a142cc50e6a5002b199bd7"
  }, {
    "url": "og-estimate.svg",
    "revision": "3a025021d61de766594925ce41935343"
  }, {
    "url": "oferta.html",
    "revision": "b7298226bdd8aea628d7ead9717992fd"
  }, {
    "url": "index.html",
    "revision": "430875e2eda47990204b94aabc33749c"
  }, {
    "url": "icon.svg",
    "revision": "3b784773f9db0bb40361f48b32305192"
  }, {
    "url": "icon.png",
    "revision": "b7fecc08132c7065421ffc992fa19205"
  }, {
    "url": "favicon.ico",
    "revision": "7f90e8787cd4f1a1d0ec07a19827bc5e"
  }, {
    "url": "donation-offer.html",
    "revision": "60f3c487047015fdbd88b7b03a59e98b"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "bfeb28770dcd7da1283b8396a9aa3042"
  }, {
    "url": "rustore/index.html",
    "revision": "7fdf52aa9a3f1d88eff47fcd306b5e71"
  }, {
    "url": "rustore/icon-512x512.png",
    "revision": "b7fecc08132c7065421ffc992fa19205"
  }, {
    "url": "assets/vendor-react-U2SifGIu.js",
    "revision": null
  }, {
    "url": "assets/vendor-icons-BSe0nMye.js",
    "revision": null
  }, {
    "url": "assets/vendor-firebase-CDLNT0-j.js",
    "revision": null
  }, {
    "url": "assets/vendor-charts-D-Nc3k4f.js",
    "revision": null
  }, {
    "url": "assets/purify.es-DBIK8olT.js",
    "revision": null
  }, {
    "url": "assets/index.es-S04ZqOqJ.js",
    "revision": null
  }, {
    "url": "assets/index-ygL-aQgE.css",
    "revision": null
  }, {
    "url": "assets/index-BUZm3Fwq.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "bfeb28770dcd7da1283b8396a9aa3042"
  }, {
    "url": "icon.svg",
    "revision": "3b784773f9db0bb40361f48b32305192"
  }, {
    "url": "manifest.json",
    "revision": "009e57cb5d8cad780d7a884171522715"
  }, {
    "url": "pwa-192x192.png",
    "revision": "f52061cbd041a7cddbb0e6bdbffeecf0"
  }, {
    "url": "pwa-512x512.png",
    "revision": "b7fecc08132c7065421ffc992fa19205"
  }, {
    "url": "manifest.webmanifest",
    "revision": "122144717172d781f9293a4a3c5170ff"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html"), {
    denylist: [/^\/donation-offer/, /^\/oferta/, /^\/offer/, /^\/terms-offer/, /^\/api\//, /^\/auth\//, /^\/yandex_/, /\.html$/, /\.gz$/]
  }));

}));
